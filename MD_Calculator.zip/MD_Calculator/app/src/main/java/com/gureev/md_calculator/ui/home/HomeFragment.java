package com.gureev.md_calculator.ui.home;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProviders;

import com.gureev.md_calculator.CalculatorStateMachine;
import com.gureev.md_calculator.R;

public class HomeFragment extends Fragment {

    private CalculatorStateMachine calculatorStateMachine;

    private TextView textViewExpr, textViewRes;
    private Button one, two, three, four, five, six, seven, eight, nine, zero;
    private Button plus, minus, div, mul, dot, saveResult, del;

    View root = null;

    private HomeViewModel homeViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             final ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        root = inflater.inflate(R.layout.fragment_home, container, false);

        one = root.findViewById(R.id.home_button_1);
        two = root.findViewById(R.id.home_button_2);
        three = root.findViewById(R.id.home_button_3);
        four = root.findViewById(R.id.home_button_4);
        five = root.findViewById(R.id.home_button_5);
        six = root.findViewById(R.id.home_button_6);
        seven = root.findViewById(R.id.home_button_7);
        eight = root.findViewById(R.id.home_button_8);
        nine = root.findViewById(R.id.home_button_9);
        zero = root.findViewById(R.id.home_button_0);

        plus = root.findViewById(R.id.home_button_plus);
        minus = root.findViewById(R.id.home_button_minus);
        div = root.findViewById(R.id.home_button_div);
        mul = root.findViewById(R.id.home_button_mul);
        dot = root.findViewById(R.id.home_button_dot);
        saveResult = root.findViewById(R.id.home_button_save);
        del = root.findViewById(R.id.home_button_del);

        textViewExpr = root.findViewById(R.id.home_editText_expression);
        textViewRes = root.findViewById(R.id.home_editText_result);

        int[] numberIds = new int[]{
                one.getId(),
                two.getId(),
                three.getId(),
                four.getId(),
                five.getId(),
                six.getId(),
                seven.getId(),
                eight.getId(),
                nine.getId(),
                zero.getId()
        };

        int[] actionIds = new int[]{
                mul.getId(),
                div.getId(),
                dot.getId(),
                plus.getId(),
                minus.getId(),
                saveResult.getId(),
                del.getId()
        };

        View.OnClickListener numButtonClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculatorStateMachine.onNumPressed(v.getId());
                //Toast.makeText(v.getContext(),calculatorStateMachine.getState(),Toast.LENGTH_SHORT).show();
                SetTextToView();
            }
        };

        View.OnClickListener actionButtonClickListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                calculatorStateMachine.onActionPressed(v.getId());
                //Toast.makeText(v.getContext(),calculatorStateMachine.getState(),Toast.LENGTH_SHORT).show();
                SetTextToView();
            }
        };

        for (int i = 0; i < numberIds.length; i++) {
            root.findViewById(numberIds[i]).setOnClickListener(numButtonClickListener);
        }

        for (int i = 0; i < actionIds.length; i++) {
            root.findViewById(actionIds[i]).setOnClickListener(actionButtonClickListener);
        }

//        textViewExpr = root.findViewById(R.id.home_editText_expression);
//        textViewRes = root.findViewById(R.id.home_editText_result);

        calculatorStateMachine = new CalculatorStateMachine();

        InitKeys();

        return root;
    }


    public void InitKeys() {
        del.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                calculatorStateMachine.resetAll();
                SetTextToView();
                return false;
            }
        });

    }

    public void SetTextToView() {
        textViewExpr.setText(calculatorStateMachine.getFormattedExpr());
        textViewRes.setText(calculatorStateMachine.getFormattedResult());
    }


}